-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 31 2021 г., 21:27
-- Версия сервера: 10.5.11-MariaDB
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `laravel_api`
--

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_08_31_163928_create_posts_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `title`, `text`, `created_at`, `updated_at`) VALUES
(1, 'Deserunt error aut ipsam qui quas unde.', 'Porro earum facilis ipsum sed. Unde doloremque cupiditate necessitatibus consequatur dicta. Earum debitis doloremque itaque autem. Qui blanditiis odio non repellat quidem provident. Dolorem sit dolores provident reiciendis. Dolore est quaerat voluptatem veniam. Iste sunt provident aut sit omnis.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(2, 'Qui quod et blanditiis repellat reiciendis.', 'Cum veritatis sunt qui earum. Dolores sit facere fugiat odit sit minus iste. Officiis odit consequatur omnis sapiente occaecati ipsam. Voluptate reprehenderit est perspiciatis corporis.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(3, 'Et non illum nemo temporibus ut sed reiciendis.', 'Animi ea et qui consequuntur dolorem non ab. Non dolores omnis possimus quasi ipsam quibusdam. Ex asperiores iste modi. Voluptatem vel dolor ipsa id consequuntur ad. Magnam qui aperiam quia assumenda perferendis. Quae quam repudiandae eligendi quis blanditiis in. Enim dolores mollitia fugit natus.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(4, 'Iusto vel laboriosam aut voluptas.', 'Totam ea quo accusamus iusto quas. Laboriosam minus odit corporis. Nemo ut id ea aut in ipsam aliquam. Possimus nulla quis est cupiditate qui.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(5, 'Numquam impedit vero quisquam.', 'Omnis unde ut illum eligendi consequuntur pariatur. Ut nisi aliquid alias atque iure. Porro magnam quas non consequatur non.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(6, 'Qui facilis molestiae ex id ullam.', 'Nihil molestiae consequatur iusto illo. Numquam quis exercitationem est et consequatur quisquam. Debitis dolores tempore ipsa non. Et earum omnis rem aut ipsam. Voluptate alias nostrum quod veniam ab earum. Itaque quis asperiores odio reiciendis voluptas quis quia. Unde est praesentium magni non.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(7, 'Aliquid rerum distinctio necessitatibus.', 'Ullam voluptas et et nesciunt omnis dolore. Et quia nam tempore numquam eaque. A nulla consequatur nostrum nemo molestias.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(8, 'Voluptate aut earum sint harum iste.', 'Officia voluptas velit fugiat omnis et in quis. Iste beatae consequuntur sit mollitia rem fugit cupiditate asperiores. Illo beatae et earum est quaerat. In aut laborum laborum inventore et.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(9, 'Ducimus illo ex velit vero.', 'Animi voluptas aliquid laudantium quaerat facere nihil. Repellendus fugiat doloremque distinctio dolorem sunt et placeat. Aliquid et sint iusto quia dolor et. Neque sed distinctio atque quas officiis.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(10, 'Consequuntur aut quia aut.', 'Omnis eligendi repellat autem vel quasi ab vitae. Eum voluptatem omnis deserunt magnam quia rerum non. Unde natus quod minus sed. Et et est rem qui. Veritatis non est omnis ex totam. Occaecati voluptatem quis molestias. Corporis qui maxime asperiores.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(11, 'Eum nesciunt ea voluptas dolores non voluptatem.', 'Alias impedit eos molestiae ea provident recusandae aut. Est laudantium voluptatem quam non harum. Tenetur inventore soluta ea quam nemo. Optio vitae praesentium rerum laudantium. Dolorem architecto id natus sed.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(12, 'Dicta modi voluptatem voluptate.', 'Nemo sed neque repudiandae nulla velit. Ut voluptatem dolores vel ut et possimus. Aut commodi rerum sit non. Voluptas fugit tempore aliquam quam a. Possimus deleniti quam assumenda pariatur in eos. Veniam est placeat numquam quas optio. Ut qui delectus nobis.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(13, 'Expedita magnam sequi nisi provident et sint aut.', 'Quo cumque tempora consequuntur laboriosam. Sapiente iste alias modi facilis sed. Enim nisi impedit tempora nesciunt temporibus excepturi quia et. Quia commodi voluptatibus molestiae et doloremque dolores earum. Aut rerum eum rerum est voluptatem quia quidem. Aut sit corporis beatae optio dolore.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(14, 'Officiis natus aspernatur illum.', 'Tempore inventore minima minima molestiae autem molestias. Expedita corrupti laudantium praesentium aut odio. Ut blanditiis et doloremque veniam explicabo rem earum culpa. Atque quos ea dolore dolorem velit ratione veniam. Id voluptatem voluptate deserunt dolore commodi aut.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(15, 'Velit officiis qui dolor aut dolore animi.', 'Aut excepturi totam illo autem ut. Incidunt mollitia dolorem et tempora vel atque.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(16, 'Quod dicta eum doloremque laboriosam qui error.', 'Est et corrupti expedita aperiam. Dolor facilis facilis quod iste eum. Doloribus earum tempora quia. Voluptas quam quia eligendi omnis deleniti ipsam. Aut minima ut quidem iste cumque et. Harum nobis non quis. Ea eum numquam aspernatur.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(17, 'Omnis ut facilis eveniet assumenda.', 'Voluptatibus sit numquam quod repudiandae voluptate et possimus. Dicta libero voluptas vel et illo iusto molestiae. Itaque omnis reiciendis alias porro sit eos. Non quia tempore veritatis necessitatibus id laboriosam earum reiciendis.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(18, 'Aspernatur sint aut ut.', 'Aut velit illum maxime ipsum aperiam aliquid nam. Voluptatem vitae eligendi eos quasi suscipit voluptatem maxime. Voluptatibus est sint modi sit quia. Aliquam repudiandae inventore consequatur nihil. Sit provident officiis et quidem dolore eos possimus.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(19, 'Accusamus hic ipsam sunt impedit est.', 'Maxime sit et sapiente velit culpa animi tempora. Et ex praesentium et saepe quasi. Sit suscipit maiores maiores recusandae. Sit qui rerum ut ea voluptate sapiente. Ex facilis dicta voluptas rem omnis sunt nam. Corrupti dignissimos aut id hic quo ea aspernatur ex. Vel quas sit possimus quia.', '2021-08-31 11:55:09', '2021-08-31 11:55:09'),
(20, 'Nemo vitae laudantium dignissimos ea molestiae.', 'Vel voluptatem odio aut praesentium. Qui dicta similique velit rerum laboriosam. Omnis fugit eum aut temporibus. Occaecati suscipit id voluptas facere id. Est officiis sit vel est quis nam deleniti. Odio iure et consequatur quia.', '2021-08-31 11:55:09', '2021-08-31 11:55:09');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
